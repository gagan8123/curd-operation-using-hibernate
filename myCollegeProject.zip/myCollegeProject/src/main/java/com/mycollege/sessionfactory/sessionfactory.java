package com.mycollege.sessionfactory;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.mycollege.entity.*;

public class sessionfactory {
	static SessionFactory sf = null;
	public static SessionFactory build() {
		if(sf!=null) {
			return sf;
		}
		Configuration cf = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(employee.class).addAnnotatedClass(student.class).addAnnotatedClass(unamepass.class);
		sf = cf.buildSessionFactory();
		return sf;
	}

}
