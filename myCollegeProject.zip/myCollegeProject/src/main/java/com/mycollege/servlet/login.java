package com.mycollege.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mycollege.entity.unamepass;
import com.mycollege.sessionfactory.sessionfactory;

/**
 * Servlet implementation class login
 */
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname = request.getParameter("uname");
		String pass = request.getParameter("pass");
		PrintWriter pw = response.getWriter();
		SessionFactory sf = sessionfactory.build();
		Session session = sf.openSession();
		List<unamepass> l = session.createQuery(" from unamepass where username='"+uname+"' and pass = '"+pass+"' ").list();
		session.close();
		if(l!=null&&l.size()==1) {
			RequestDispatcher rd = request.getRequestDispatcher("viewdatastd");
			rd.forward(request, response);
		}
		else {
		pw.println("<html><body>no user found</body></html>");
		}
		
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
