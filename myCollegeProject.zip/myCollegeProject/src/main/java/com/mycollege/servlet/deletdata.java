package com.mycollege.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mycollege.sessionfactory.sessionfactory;

/**
 * Servlet implementation class deletdata
 */
public class deletdata extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deletdata() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id1 = request.getParameter("id1");
		String id2 = request.getParameter("id2");
		SessionFactory sf = sessionfactory.build();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		PrintWriter pw = response.getWriter();
		
		if(id1 != null) {
			int i =session.createSQLQuery("delete from student where id = '"+id1+"'").executeUpdate();
			session.close();
			if(i==1) {
				RequestDispatcher rd = request.getRequestDispatcher("viewdatastd");
				rd.forward(request, response);
			}
			else {
				pw.println("<html><body>no data found</body></html>");
				session.close();
			}
		}
		else if(id2 !=null) {
			int i =session.createSQLQuery("delete from employee where id = '"+id2+"' ").executeUpdate();
			if(i==1) {
				RequestDispatcher rd = request.getRequestDispatcher("viewdatastd");
				rd.forward(request, response);
				session.close();
			}
			else {
				pw.println("<html><body>no data found</body></html>");
				session.close();
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
