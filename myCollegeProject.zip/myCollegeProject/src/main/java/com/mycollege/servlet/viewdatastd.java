package com.mycollege.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mycollege.entity.employee;
import com.mycollege.entity.student;
import com.mycollege.sessionfactory.sessionfactory;

/**
 * Servlet implementation class viewdatastd
 */
public class viewdatastd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewdatastd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SessionFactory sf = sessionfactory.build();
		Session session = sf.openSession();
		List<employee> emp = session.createQuery(" from employee ").list();
		List<student> std = session.createQuery(" from student ").list();
		RequestDispatcher rd = request.getRequestDispatcher("main.jsp");
		request.setAttribute("emp", emp);
		request.setAttribute("std", std);
		rd.forward(request, response);
		session.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
