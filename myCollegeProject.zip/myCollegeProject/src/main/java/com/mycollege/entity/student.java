package com.mycollege.entity;

import javax.persistence.*;

@Entity
@Table
public class student {
	@Id
	@GeneratedValue
	private String id;
	@Column
	private String name;
	@Column
	private String course;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	

}
